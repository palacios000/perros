ProcessWire ProFields: Functional Fields 
========================================
(fields defined by functions)

This is a commercial module, part of the ProFields package. Do not distribute.

For usage instructions, please see the blog post at:
https://processwire.com/blog/posts/functional-fields/


HOW TO INSTALL
--------------
1. Copy all the files in this directory to /site/modules/FieldtypeFunctional/ 
2. In your admin, go to Modules > Check for new modules. 
3. Click the "Install" button next to Fieldtype > Functional.
4. Create a new field (Setup > Fields > Add), choose "Functional" as type. 

USAGE
-----
Additional documentation to be added after beta. Please see the blog post
for current information about how to use and implement Functional fields:
https://processwire.com/blog/posts/functional-fields/


Copyright 2020 by Ryan Cdramer
